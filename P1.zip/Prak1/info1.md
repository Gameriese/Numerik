# Anleitung zum Ausfüllen

1.  Überschrift-Zeilen, die mit "#" beginnen, unverändert lassen.
2.  Leerzeilenn unverändert lassen.
3.  Bestätigung am Ende LESEN und unverändert lassen.
4.  Teamname durch einen selbst gewählten Teamnamen ersetzen.
5.  Namen im Format "Nachname, Vorname(n)" eintragen. 
    Bitte arbeiten Sie in 2-er Teams zusammen.
    Sollte es Ihnen nicht gelingen eine Partnerin bzw. einen Partner zu finden,
    melden Sie sich bei mir. Sollten Sie trotzdem alleine arbeiten und abgeben
    wollen, tragen Sie unter "Teilnehmer 2" nur KEINER (in Großbuchstaben) ein.
6.  Email bzw. KEINE (in Großbuchstaben) eintragen.

# Daten zur Abgabe

## Team
Königin der Mathematik

## Teilnehmer 1
Zizer, Lukas

## Teilnehmer 2
Zizer, Lukas

## Email 1
lukaszizer@web.de

## Email 2
lukaszizer@web.de

## Quellen
Numerik Skript

## Bemerkungen
Was Sie sonst noch los werden wollen.

## Bestätigung
Ich / wir bestätigen, dass wir nur die angegebenen Quellen benutzt haben.
